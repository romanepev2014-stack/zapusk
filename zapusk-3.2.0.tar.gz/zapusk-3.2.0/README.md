# 🎮 ZAPUSK 3.0

**A launcher for Windows games on Linux & FreeBSD: drop a .exe in — everything configures itself.**

[![Release](https://img.shields.io/github/v/release/romanepev2014-stack/zapusk)](https://github.com/romanepev2014-stack/zapusk/releases)
[![License: GPL v3](https://img.shields.io/badge/license-GPL--3.0-blue)](LICENSE)

## 🧨 What's new in 3.0

- 🔧 **Auto-Heal** — game crashes → Zapusk reads the log, diagnoses (DXVK, vcrun, d3dx9, .NET, memory, fsync), applies the fix and relaunches — up to 4 attempts. Nobody else does this
- 📥 **Universal import** — Steam, Heroic, Lutris, Bottles, GOG: one button gathers all your Windows games into one library
- ⏪ **Prefix Time Machine** — snapshot before risky changes, one-click rollback
- 🔮 **Compat oracle** — honestly warns you before launching unfixable games
- 💀 **Panic kill** — instantly kills a frozen game (every wine/proton process)
- 📊 **Full monitoring** — MSI Afterburner-level overlay: FPS, frametime, CPU/GPU, RAM/VRAM (right Shift+F12)
- ⬆ **Self-update** — a button in settings downloads the right package for your distro
- 🪟 **Windows XP theme** — Bliss desktop, taskbar with a **real Start menu** (all navigation inside) and a **playable Minesweeper** (drawn flags, spiky mines, smiley with sunglasses)
- 🪟 **Windows 95 theme** — working Start menu, chunky bevels, pure nostalgia

## ⚡ Usage

1. Install the package for your system (below) or run `./install.sh` — it detects your distro
2. Run `zapusk` (or the menu icon)
3. Drag an .exe or a game folder into the window — Zapusk detects DirectX and picks a preset
4. Press **"Fix & Launch"** — it handles the rest

## 📦 Install

| System | Command |
|---|---|
| Arch / Manjaro | `sudo pacman -U zapusk-3.0.0-1-any.pkg.tar.zst` |
| Debian / Ubuntu | `sudo apt install ./zapusk_3.0.0_all.deb` |
| Fedora / openSUSE | `sudo dnf install ./zapusk-3.0.0-1.noarch.rpm` |
| Any Linux | `./zapusk-3.0.0-x86_64.AppImage` |
| FreeBSD | `sh scripts/build_freebsd_pkg.sh` (from source) |
| From source | `git clone ... && cd zapusk && python3 -m zapusk gui` |

## 🌍 Features

- 🌐 10 UI languages
- 🎨 6 themes: Cyber, Matrix, Sunset, Sakura, Windows XP, Windows 95 — animated backgrounds with parallax
- ⚡ Auto-config: PE-import analysis detects DirectX 9/11/12 and engine, installs DXVK, vcrun, d3dx9, fonts
- 🧊 DXVK + VKD3D-Proton — DirectX via Vulkan; DXVK auto-downloads if your repos lack it
- 🐧 **Any distro**: Arch, Debian, Ubuntu, Fedora, openSUSE, Void, Alpine, Gentoo — `install.sh` detects the package manager
- 🚀 **FreeBSD Gaming Mode** — bhyve + GPU passthrough + Looking Glass: heavy games on FreeBSD at 100% GPU speed
- 🗑 Remove games: from list, with files, with prefix
- 💾 Library export/restore (JSON)

## 💻 CLI

```bash
zapusk doctor              # system diagnostics
zapusk import              # import from Steam/Heroic/Lutris/Bottles/GOG
zapusk run "GTA5" --fix    # launch with auto-heal
zapusk kill "GTA5"         # panic kill
zapusk snapshot "GTA5"     # prefix snapshot
zapusk rollback "GTA5"     # prefix rollback
zapusk update              # self-update
```

## ❓ Honest answers

- **Anti-cheats** (Vanguard, kernel-level) — don't work anywhere outside the official Windows client; Zapusk warns you upfront
- **Linux-native Steam games** — play them natively; Zapusk imports Windows builds (including forced-Proton ones)
- Written by a 12-year-old developer with an AI assistant. **GPL-3.0**: code always open, forks welcome

## 📤 Repos & packages

Arch (PKGBUILD/AUR soon), Flathub (after development history matures), COPR, PPA, Snap, Nix, Gentoo, Void, Alpine, FreeBSD Ports — see [RELEASE.md](RELEASE.md).
