# 🎮 ZAPUSK 3.0

**Лаунчер Windows-игр для Linux и FreeBSD: кинул .exe — всё настроилось само.**

[![Release](https://img.shields.io/github/v/release/romanepev2014-stack/zapusk)](https://github.com/romanepev2014-stack/zapusk/releases)
[![License: GPL v3](https://img.shields.io/badge/license-GPL--3.0-blue)](LICENSE)

## 🧨 Что нового в 3.0

- 🔧 **Авто-лечение** — игра вылетела → Zapusk сам читает лог, определяет причину (DXVK, vcrun, d3dx9, .NET, память, fsync), чинит и перезапускает до 4 попыток. Такого нет ни у кого
- 📥 **Импорт из всех магазинов** — Steam, Heroic, Lutris, Bottles, GOG: одна кнопка собирает все Windows-игры в одну библиотеку
- ⏪ **Машина времени префикса** — снапшот перед рискованными действиями, откат в один клик
- 🔮 **Оракул совместимости** — честно предупреждает до запуска: «эта игра не заведётся, вот почему»
- 💀 **Паник-килл** — мгновенно убивает зависшую игру (все процессы wine/proton)
- 📊 **Полный мониторинг** — оверлей уровня MSI Afterburner: FPS, фреймтайм, CPU/GPU, RAM/VRAM (правая Shift+F12)
- ⬆ **Самообновление** — кнопка в настройках: сам качает пакет под твой дистрибутив
- 🪟 **Тема Windows XP** — рабочий стол Блисс, панель задач с **настоящим меню «Пуск»** (вся навигация внутри) и **играбельным Сапёром** (нарисованные флажки, мины, смайлик в очках)
- 🪟 **Тема Windows 95** — рабочий Пуск, угловатые бевелы, ностальгия

## ⚡ Как пользоваться

1. Установи пакет под свою систему (см. ниже) или запусти `./install.sh` — он определит дистрибутив сам
2. Запусти `zapusk` (или ярлык в меню)
3. Перетащи .exe или папку с игрой в окно — Zapusk определит DirectX и пресет
4. Нажми **«Починить и запустить»** — всё остальное он сделает сам

## 📦 Установка

| Система | Команда |
|---|---|
| Arch / Manjaro | `sudo pacman -U zapusk-3.0.0-1-any.pkg.tar.zst` |
| Debian / Ubuntu | `sudo apt install ./zapusk_3.0.0_all.deb` |
| Fedora / openSUSE | `sudo dnf install ./zapusk-3.0.0-1.noarch.rpm` |
| Любой Linux | `./zapusk-3.0.0-x86_64.AppImage` |
| FreeBSD | `sh scripts/build_freebsd_pkg.sh` (из исходников) |
| Из исходников | `git clone ... && cd zapusk && python3 -m zapusk gui` |

Скриншоты и демо — в [релизе](https://github.com/romanepev2014-stack/zapusk/releases).

## 🎮 Console Mode (3.1)

Кидай ISO от консолей — Zapusk **сам определит платформу по сигнатурам образа** (серийники PS, магические байты Xbox), **сам поставит эмулятор** (пакетный менеджер → flatpak → скачивание) и запустит:

- **PlayStation 1/2/3, PSP** — DuckStation, PCSX2, RPCS3 (с автоустановкой прошивки), PPSSPP
- **Xbox (original)** — xemu
- **PlayStation 4** — shadPS4 (экспериментально, часть библиотеки работает)
- **PS5** — эмулятора не существует, честно ждём
- **Xbox 360** — Xenia, запускаемая **через наш собственный префикс Wine с DXVK** (прослойка на прослойке)
- `zapusk consoles` — статус всех эмуляторов

## 🐧 FreeBSD GPU Layer

Индивидуальная настройка FreeBSD под игры: `zapusk fbsdgpu` определит вашу видеокарту, установит **только её** драйвер, **удалит ненужные**, запомнит железо — при замене карты следующий запуск всё перенастроит. Флаг `--kernel` собирает тюнингованное ядро под вашу систему.

## 🌍 Возможности

- 🌐 10 языков интерфейса
- 🎨 6 тем оформления: Cyber, Matrix, Sunset, Sakura, Windows XP, Windows 95 — у каждой анимированный фон и параллакс
- ⚡ Авто-настройка: анализ PE-импортов определяет DirectX 9/11/12 и движок, ставит DXVK, vcrun, d3dx9, шрифты
- 🧊 DXVK + VKD3D-Proton — DirectX через Vulkan; DXVK качается сам, если его нет в репозиториях
- 🐧 **Любой дистрибутив**: Arch, Debian, Ubuntu, Fedora, openSUSE, Void, Alpine, Gentoo — `install.sh` сам определит пакетный менеджер
- 🚀 **FreeBSD Gaming Mode** — bhyve + GPU passthrough + Looking Glass: тяжёлые игры на FreeBSD со 100% скоростью GPU
- 🗑 Удаление игр: из списка, с файлами, с префиксом
- 💾 Экспорт/восстановление библиотеки (JSON)

## 💻 CLI

```bash
zapusk doctor              # диагностика системы
zapusk import              # импорт игр из Steam/Heroic/Lutris/Bottles/GOG
zapusk run "GTA5" --fix    # запуск с авто-лечением
zapusk kill "GTA5"         # паник-килл
zapusk snapshot "GTA5"     # снапшот префикса
zapusk rollback "GTA5"     # откат префикса
zapusk update              # самообновление
```

## ❓ Честные ответы

- **Античиты** (Vanguard и ядерные) — не работают нигде вне официального Windows-клиента; Zapusk честно предупредит заранее
- **Steam-игры на Linux** — если у игры есть нативная Linux-версия, играй в ней напрямую; Zapusk импортирует Windows-версии (включая игры через принудительный Proton)
- Проект написан 12-летним разработчиком при поддержке ИИ-ассистента. **GPL-3.0**: код всегда открыт, форки приветствуются

## 📤 Репозитории и пакеты

Arch (PKGBUILD/AUR — скоро), Flathub (после набора истории разработки), COPR, PPA, Snap, Nix, Gentoo, Void, Alpine, FreeBSD Ports — инструкции в [RELEASE.md](RELEASE.md).
