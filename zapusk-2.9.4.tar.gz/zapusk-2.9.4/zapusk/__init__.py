__version__ = "2.9.4"
APP_NAME = "Zapusk"
