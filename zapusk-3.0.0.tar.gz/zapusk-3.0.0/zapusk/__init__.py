__version__ = "3.0.0"
APP_NAME = "Zapusk"
